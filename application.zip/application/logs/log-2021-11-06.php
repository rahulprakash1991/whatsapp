<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-06 06:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-06 06:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-06 06:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-06 06:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-06 06:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-06 06:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-06 06:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-06 06:48:32 --> Severity: Parsing Error --> syntax error, unexpected '$dd' (T_VARIABLE) E:\xamp\htdocs\crm\application\views\sales_order\print_sales_order.php 158
ERROR - 2021-11-06 06:52:35 --> Severity: Parsing Error --> syntax error, unexpected ''\n'' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 06:52:38 --> Severity: Parsing Error --> syntax error, unexpected ''\n'' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 06:52:48 --> Severity: Parsing Error --> syntax error, unexpected '"Vender Name :"' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 06:52:49 --> Severity: Parsing Error --> syntax error, unexpected '"Vender Name :"' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 06:52:59 --> Severity: Parsing Error --> syntax error, unexpected '"Vender Name :"' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 06:52:59 --> Severity: Parsing Error --> syntax error, unexpected '"Vender Name :"' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 08:18:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\viewform.php 80
ERROR - 2021-11-06 08:20:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\viewform.php 80
ERROR - 2021-11-06 08:20:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\viewform.php 80
ERROR - 2021-11-06 08:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\viewform.php 80
ERROR - 2021-11-06 08:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\viewform.php 80
ERROR - 2021-11-06 08:34:55 --> Query error: Column 'sal_id' cannot be null - Invalid query: INSERT INTO `customet_payment` (`sal_id`, `customer_id`, `paid_amt`, `collection_date`, `transaction_date`, `mode`, `transaction_no`, `bank_name`, `customer_remark`, `created_on`) VALUES (NULL, '1', '2875.00', '2021-11-06', '2021-11-06', '1', '', '', NULL, '2021-11-06 08:34:55')
ERROR - 2021-11-06 08:34:55 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `sal_payment` (`invoice_id`, `amount`, `date`, `transaction_date`, `payment_mode`, `transaction_number`, `transaction_bank_name`, `account_heads`, `created_on`, `created_by`) VALUES (NULL, '2875.00', '2021-11-06', '2021-11-06', '1', '', '', '1', '4196495414', '2021-11-06 08:34:55')
ERROR - 2021-11-06 08:45:16 --> Severity: Error --> Call to undefined function AmountInWords() E:\xamp\htdocs\crm\application\views\sales_order\print_sales_order.php 332
ERROR - 2021-11-06 10:24:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\viewform.php 80
ERROR - 2021-11-06 10:30:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\print_sales_order.php 63
ERROR - 2021-11-06 10:30:34 --> Severity: Warning --> Missing argument 6 for Sales_order::QRcode() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-06 10:30:35 --> Severity: Warning --> Missing argument 6 for Sales_order::QRcode() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-06 10:32:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\print_sales_order.php 63
ERROR - 2021-11-06 10:32:23 --> Severity: Warning --> Missing argument 6 for Sales_order::QRcode() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-06 10:32:24 --> Severity: Warning --> Missing argument 6 for Sales_order::QRcode() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-06 10:33:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\print_sales_order.php 63
ERROR - 2021-11-06 10:34:53 --> Severity: Warning --> explode(): Empty delimiter E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 10:34:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 890
ERROR - 2021-11-06 10:34:54 --> Severity: Warning --> explode(): Empty delimiter E:\xamp\htdocs\crm\application\controllers\Sales_order.php 888
ERROR - 2021-11-06 10:34:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 890
ERROR - 2021-11-06 10:37:23 --> Severity: Parsing Error --> syntax error, unexpected '$Qr_data' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\Sales_order.php 895
ERROR - 2021-11-06 10:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\sales_order\viewform.php 80
