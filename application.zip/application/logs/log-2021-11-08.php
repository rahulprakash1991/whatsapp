<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-08 06:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-08 06:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-08 06:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-08 06:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-08 06:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-08 06:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-08 06:31:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-08 08:15:34 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:15:36 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:16:42 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:16:45 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:16:47 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:18:05 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:18:43 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:19:00 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:23:54 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:23:55 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:23:56 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:24:00 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:30:05 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:30:06 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:30:06 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:30:07 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:30:08 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:36:54 --> Severity: Notice --> Use of undefined constant LOGIN_PAGE - assumed 'LOGIN_PAGE' E:\xamp\htdocs\crm\application\third_party\community_auth\core\Auth_Controller.php 191
ERROR - 2021-11-08 08:36:54 --> Severity: Notice --> Use of undefined constant AUTH_REDIRECT_PARAM - assumed 'AUTH_REDIRECT_PARAM' E:\xamp\htdocs\crm\application\third_party\community_auth\core\Auth_Controller.php 294
ERROR - 2021-11-08 08:36:54 --> Severity: Notice --> Use of undefined constant USE_SSL - assumed 'USE_SSL' E:\xamp\htdocs\crm\application\third_party\community_auth\core\Auth_Controller.php 299
ERROR - 2021-11-08 08:36:54 --> Severity: Notice --> Use of undefined constant LOGIN_PAGE - assumed 'LOGIN_PAGE' E:\xamp\htdocs\crm\application\third_party\community_auth\core\Auth_Controller.php 306
ERROR - 2021-11-08 08:36:54 --> Severity: Notice --> Use of undefined constant AUTH_REDIRECT_PARAM - assumed 'AUTH_REDIRECT_PARAM' E:\xamp\htdocs\crm\application\third_party\community_auth\core\Auth_Controller.php 306
ERROR - 2021-11-08 08:36:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xamp\htdocs\crm\system\core\Exceptions.php:272) E:\xamp\htdocs\crm\application\third_party\community_auth\core\Auth_Controller.php 309
ERROR - 2021-11-08 08:37:22 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:37:38 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:37:46 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:38:38 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:42:37 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:42:40 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:47:01 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:47:02 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:47:04 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 53
ERROR - 2021-11-08 08:48:50 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:48:56 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:51:01 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:51:02 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:52:32 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:52:34 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:52:40 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:53:14 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:53:15 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:56:47 --> Could not find the language line "login_identity_label"
ERROR - 2021-11-08 08:56:49 --> Could not find the language line "login_identity_label"
