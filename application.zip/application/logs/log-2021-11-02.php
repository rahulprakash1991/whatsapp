<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-02 15:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-02 15:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-02 15:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-02 15:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-02 15:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-02 15:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-02 15:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-02 15:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-02 15:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-02 15:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-02 15:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-02 15:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-02 15:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-02 15:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
