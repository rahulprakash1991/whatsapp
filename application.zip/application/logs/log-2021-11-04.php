<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-04 06:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 06:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 06:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 06:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 06:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 06:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 06:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 06:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 06:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 06:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 06:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 06:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 06:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 06:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 09:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 10:02:21 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 337
ERROR - 2021-11-04 10:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 10:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 10:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 10:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 10:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 10:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 10:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 10:31:10 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 29
ERROR - 2021-11-04 10:31:15 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 29
ERROR - 2021-11-04 10:31:33 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 29
ERROR - 2021-11-04 10:33:24 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 40
ERROR - 2021-11-04 10:33:25 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 40
ERROR - 2021-11-04 10:34:42 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 40
ERROR - 2021-11-04 10:34:44 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 40
ERROR - 2021-11-04 10:34:45 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 40
ERROR - 2021-11-04 10:35:23 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 14
ERROR - 2021-11-04 10:35:36 --> Severity: Error --> Call to undefined function encryptIt() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 41
ERROR - 2021-11-04 10:35:52 --> Unable to load the requested class: EncryptIt
ERROR - 2021-11-04 10:38:01 --> Severity: Notice --> Undefined variable: qDecoded E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 48
ERROR - 2021-11-04 10:45:54 --> Severity: Notice --> Undefined variable: total2 E:\xamp\htdocs\crm\application\views\dashboard.php 55
ERROR - 2021-11-04 10:45:54 --> Severity: Notice --> Undefined variable: Outstanding_receivables E:\xamp\htdocs\crm\application\views\dashboard.php 81
ERROR - 2021-11-04 10:45:54 --> Severity: Notice --> Undefined variable: data E:\xamp\htdocs\crm\application\views\dashboard.php 107
ERROR - 2021-11-04 10:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 10:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 10:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 10:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 10:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 10:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 10:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:01:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 11:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:09:21 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 135
ERROR - 2021-11-04 11:09:32 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 135
ERROR - 2021-11-04 11:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:48:58 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 11:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 11:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 11:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 11:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 11:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 11:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 11:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 12:01:49 --> Severity: 4096 --> Object of class User_registration could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 315
ERROR - 2021-11-04 12:01:54 --> Severity: 4096 --> Object of class User_registration could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 315
ERROR - 2021-11-04 12:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 12:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 12:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 12:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 12:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 12:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 12:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 12:34:57 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-04 12:35:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-04 12:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 12:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 12:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 12:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 12:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 12:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 12:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 12:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 12:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 12:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 12:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 12:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 12:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 12:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 12:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 12:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 12:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 12:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 12:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 12:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 12:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 13:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 13:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 13:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 13:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 13:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 13:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 13:04:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 13:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 13:06:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 13:06:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-04 13:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 13:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 13:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 13:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 13:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 13:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 13:07:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 13:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 13:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 13:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 13:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 13:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 13:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 13:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:44:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-04 13:54:52 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\purchase_order\payment_details.php 69
ERROR - 2021-11-04 14:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 14:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 14:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 14:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 14:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 14:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 14:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 14:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 14:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 14:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 14:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 14:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 14:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 14:47:38 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 14:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 14:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 14:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 14:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 14:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 14:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 14:51:50 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 14:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 14:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 14:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 14:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 14:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 14:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 14:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-04 14:55:39 --> Severity: Parsing Error --> syntax error, unexpected '--' (T_DEC) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 438
ERROR - 2021-11-04 15:00:32 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-04 15:04:59 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-04 15:04:59 --> Severity: Error --> Call to undefined method Common_model::find_user_id_email() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-04 15:05:56 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-04 15:05:56 --> Severity: Error --> Call to undefined method Common_model::find_user_id_email() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-04 15:06:06 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-04 15:06:06 --> Severity: Error --> Call to undefined method Common_model::find_user_id_email() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-04 15:06:11 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-04 15:06:11 --> Severity: Error --> Call to undefined method Common_model::find_user_id_email() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-04 15:07:32 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-04 15:07:32 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-04 15:07:32 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-04 15:07:32 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-04 15:07:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-04 15:07:32 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-04 15:07:32 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-04 15:07:50 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-04 15:07:50 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-04 15:07:50 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-04 15:07:50 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-04 15:07:50 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-04 15:07:50 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-04 15:07:50 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-04 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-04 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-04 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-04 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-04 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-04 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-04 15:08:27 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
