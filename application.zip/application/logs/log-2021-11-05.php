<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-05 05:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 05:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 05:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 05:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 05:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 05:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 05:36:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 05:37:19 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 05:37:19 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 05:37:19 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 05:37:19 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 05:37:19 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 05:37:19 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 05:37:19 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 05:38:35 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 05:38:35 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 05:38:35 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 05:38:35 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 05:38:35 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 05:38:35 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 05:38:35 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 05:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 05:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 05:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 05:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 05:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 05:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 05:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 05:40:15 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 05:40:15 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 05:40:15 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 05:40:15 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 05:40:15 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 05:40:15 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 05:40:15 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 06:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 06:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 06:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 06:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 06:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 06:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 06:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 06:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 06:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 06:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 06:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 06:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 06:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 06:03:06 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:03:06 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:03:06 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:03:06 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:03:06 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:03:06 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:03:06 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 06:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 06:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 06:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 06:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 06:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 06:03:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 06:05:14 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:05:14 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:05:14 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:05:14 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:05:14 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:05:14 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:05:14 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:05:50 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:05:50 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:05:50 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:05:50 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:05:50 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:05:50 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:05:50 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:05:52 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:05:52 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:05:52 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:05:52 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:05:52 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:05:52 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:05:52 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:07:44 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:07:44 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:07:44 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:07:44 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:07:44 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:07:44 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:07:44 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:07:45 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:07:45 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:07:45 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:07:45 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:07:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:07:45 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:07:45 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:07:51 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:07:51 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:07:51 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:07:51 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:07:51 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:07:51 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:07:51 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:11 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:09:11 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:09:11 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:09:11 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:11 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:11 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:11 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:27 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:09:27 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:09:27 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:09:27 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:27 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:27 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:28 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:09:28 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:09:28 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:09:28 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:28 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:28 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:28 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:30 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:09:30 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:09:30 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:09:30 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:30 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:09:30 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:30 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:09:49 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:10:54 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:10:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:11:12 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:11:12 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:11:12 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:11:12 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:11:12 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:11:12 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:11:12 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:11:15 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:11:15 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:11:15 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:11:15 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:11:15 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:11:15 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:11:15 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:11:39 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:11:39 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:11:56 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:11:56 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:11:56 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:12:17 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:12:17 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:12:17 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:12:17 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:17 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:41 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:12:41 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:12:41 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:12:41 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:41 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:12:41 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:12:44 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:12:44 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:12:44 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:12:44 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:44 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:44 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:12:44 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:12:45 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:12:45 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:12:45 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:12:45 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:12:45 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:12:45 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 06:13:02 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:13:02 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:13:02 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:13:02 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:02 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:34 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:13:34 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:13:34 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:13:34 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:34 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:34 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:13:52 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:13:52 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:13:52 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:13:52 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:52 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:52 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:13:52 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:13:54 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:13:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:13:54 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:13:54 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:13:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:13:54 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:14:13 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:14:13 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:14:13 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:14:13 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:13 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:14:13 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:14:15 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:14:15 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:14:15 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:14:15 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:15 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:15 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:14:15 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:14:44 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:14:44 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:14:44 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:14:44 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:44 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:44 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:14:44 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:14:47 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:14:47 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:14:47 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:14:47 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:47 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:14:47 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:14:47 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:15:12 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:15:12 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:15:12 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:15:12 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:15:12 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:15:12 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:15:32 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:15:32 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:15:32 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:15:32 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:15:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:15:32 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:15:54 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:15:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:15:54 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:15:54 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:15:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:15:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:16:19 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:16:19 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:16:19 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:16:19 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:16:19 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:16:19 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:16:35 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:16:35 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:16:35 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:16:35 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:16:35 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:16:35 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:16:35 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:16:38 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:16:38 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:16:38 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:16:38 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:16:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:16:38 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:16:38 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:17:50 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:17:50 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:17:50 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:17:50 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:17:50 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:17:50 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:17:50 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:17:52 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:17:52 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:17:52 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:17:52 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:17:52 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:17:52 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:17:52 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:18:12 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:18:12 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:18:12 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:18:12 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:18:12 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:18:12 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:18:12 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:18:13 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:18:13 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:18:13 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:18:13 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:18:13 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:18:13 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:18:13 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:19:24 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:19:24 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:19:24 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:19:24 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:19:24 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:19:24 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:19:41 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:19:41 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:19:41 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:19:41 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:19:41 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:19:41 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:20:00 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:20:00 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:20:00 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:20:00 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:00 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:00 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:20:15 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:20:15 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:20:15 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:20:15 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:15 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:15 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:20:15 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:20:18 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:20:18 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:20:18 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:20:18 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:18 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:20:18 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:19 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:20:19 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:19 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:19 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:20:19 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:20:20 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:20:20 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:20:20 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:20:20 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:20 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:20:20 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:20:20 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:21:30 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:21:30 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:21:30 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:21:30 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:30 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:30 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:21:30 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:31 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:21:31 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:31 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:31 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:21:31 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:21:32 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:21:32 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:21:32 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:21:32 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:32 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:21:32 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:21:32 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:22:45 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:22:45 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:22:45 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:22:45 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:22:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:22:45 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:23:03 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:23:03 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:23:03 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:23:03 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:23:03 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:23:03 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:23:16 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:23:16 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:23:16 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:23:16 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:23:16 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:23:16 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:23:36 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:23:36 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:23:36 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:23:36 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:23:36 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:23:36 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 06:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 06:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 06:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 06:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 06:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 06:25:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 06:25:43 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:25:43 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:25:43 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:25:43 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:25:43 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:25:43 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 06:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 06:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 06:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 06:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 06:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 06:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 06:27:40 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:27:40 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:27:40 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:27:40 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:27:40 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:27:40 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:27:40 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:28:34 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:28:34 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:28:34 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:28:34 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:28:34 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:28:34 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:28:34 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:28:35 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:28:35 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:28:35 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:28:35 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:28:35 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:28:35 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:28:35 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:29:04 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:29:04 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:29:04 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:29:04 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:29:04 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:29:04 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:29:04 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:29:18 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:29:18 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:29:18 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:29:18 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:29:18 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:29:18 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:29:45 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:29:45 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:29:45 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:29:45 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:29:45 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:29:45 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:29:45 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 06:31:20 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 710
ERROR - 2021-11-05 06:31:20 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 06:31:20 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 06:31:20 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:31:20 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 06:31:20 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 719
ERROR - 2021-11-05 06:40:51 --> Severity: Parsing Error --> syntax error, unexpected ',' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 432
ERROR - 2021-11-05 06:42:10 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 06:45:27 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 06:57:40 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 06:57:58 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 06:57:59 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 06:58:13 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 06:58:13 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:00:07 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:00:08 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:00:25 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:00:45 --> Severity: Notice --> Undefined variable: form_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 73
ERROR - 2021-11-05 07:00:45 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 85
ERROR - 2021-11-05 07:00:45 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 136
ERROR - 2021-11-05 07:00:45 --> Severity: Notice --> Undefined variable: old_string E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 175
ERROR - 2021-11-05 07:00:45 --> Severity: Notice --> Undefined variable: list_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 226
ERROR - 2021-11-05 07:00:45 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-05 07:00:45 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-05 07:05:26 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 436
ERROR - 2021-11-05 07:05:35 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 436
ERROR - 2021-11-05 07:06:15 --> Severity: Parsing Error --> syntax error, unexpected '.=' (T_CONCAT_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:07:06 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:07:31 --> Severity: Parsing Error --> syntax error, unexpected '0' (T_LNUMBER) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:07:46 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 436
ERROR - 2021-11-05 07:07:48 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 436
ERROR - 2021-11-05 07:08:25 --> Severity: Parsing Error --> syntax error, unexpected '=' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:08:57 --> Severity: Notice --> Undefined variable: form_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 73
ERROR - 2021-11-05 07:08:57 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 85
ERROR - 2021-11-05 07:08:57 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 136
ERROR - 2021-11-05 07:08:57 --> Severity: Notice --> Undefined variable: old_string E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 175
ERROR - 2021-11-05 07:08:57 --> Severity: Notice --> Undefined variable: list_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 226
ERROR - 2021-11-05 07:08:58 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-05 07:08:58 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-05 07:14:27 --> Severity: Parsing Error --> syntax error, unexpected '' == 0){ selected  }>NO</optio' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:18:29 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:18:51 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:18:52 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:18:53 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:19:40 --> Severity: Parsing Error --> syntax error, unexpected ''){ selected  }>NO</option>' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:19:41 --> Severity: Parsing Error --> syntax error, unexpected ''){ selected  }>NO</option>' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:20:12 --> Severity: Parsing Error --> syntax error, unexpected '=' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:20:13 --> Severity: Parsing Error --> syntax error, unexpected '=' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:20:33 --> Severity: Parsing Error --> syntax error, unexpected '=' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:20:34 --> Severity: Parsing Error --> syntax error, unexpected '=' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:20:50 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:20:51 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:21:04 --> Severity: Parsing Error --> syntax error, unexpected ''){ selected  }>NO</option>' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:21:05 --> Severity: Parsing Error --> syntax error, unexpected ''){ selected  }>NO</option>' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:21:21 --> Severity: Parsing Error --> syntax error, unexpected ''){ selected  }>NO</option>' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:21:22 --> Severity: Parsing Error --> syntax error, unexpected ''){ selected  }>NO</option>' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:21:23 --> Severity: Parsing Error --> syntax error, unexpected ''){ selected  }>NO</option>' (T_CONSTANT_ENCAPSED_STRING) E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 435
ERROR - 2021-11-05 07:21:46 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:22:00 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:22:00 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:22:01 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:22:01 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:22:01 --> Severity: Parsing Error --> syntax error, unexpected '.' E:\xamp\htdocs\crm\application\helpers\datatables_helper.php 434
ERROR - 2021-11-05 07:42:56 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:42:56 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 07:42:56 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:42:56 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:42:56 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:42:56 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 720
ERROR - 2021-11-05 07:43:24 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:43:24 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 07:43:24 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:43:24 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:43:24 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:43:24 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 720
ERROR - 2021-11-05 07:43:47 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:43:47 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 07:43:47 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:43:47 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:43:47 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:43:47 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 720
ERROR - 2021-11-05 07:43:47 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 741
ERROR - 2021-11-05 07:44:57 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:44:57 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 07:44:57 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:44:57 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:44:57 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:44:57 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 720
ERROR - 2021-11-05 07:45:36 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:45:36 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 07:45:36 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:45:36 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:45:36 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:45:36 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 720
ERROR - 2021-11-05 07:45:36 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 741
ERROR - 2021-11-05 07:46:05 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:46:05 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 712
ERROR - 2021-11-05 07:46:05 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:46:05 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:46:05 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:46:05 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 720
ERROR - 2021-11-05 07:46:05 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 741
ERROR - 2021-11-05 07:47:11 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:47:11 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:47:11 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:47:11 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:47:11 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:47:11 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:49:36 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:49:36 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:49:36 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:49:36 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:49:36 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:49:36 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:49:36 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 3
ERROR - 2021-11-05 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 07:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 07:51:22 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:51:22 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:51:22 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:51:22 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:51:22 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:51:22 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 07:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 07:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 07:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 07:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 07:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 07:51:55 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 07:53:02 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:53:02 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:53:02 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:53:02 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:53:02 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:53:02 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:55:00 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:55:00 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:55:00 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:55:00 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:55:00 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:55:00 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:55:00 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\test.php 3
ERROR - 2021-11-05 07:56:04 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:56:04 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:56:04 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:56:04 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:56:04 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:56:04 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:56:54 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:56:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:56:54 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:56:54 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:56:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:56:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:57:49 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 07:57:49 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 07:57:49 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 07:57:49 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:57:49 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 07:57:49 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 07:57:49 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 733
ERROR - 2021-11-05 07:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 07:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 07:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 07:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 07:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 07:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 07:58:25 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 08:00:08 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 08:00:08 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 08:00:08 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 08:00:08 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 08:00:08 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 08:00:08 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 716
ERROR - 2021-11-05 08:00:08 --> Severity: Error --> Call to a member function result() on string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 716
ERROR - 2021-11-05 08:01:54 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 08:01:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 08:01:54 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 08:01:54 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 08:01:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 08:01:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 08:02:51 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 711
ERROR - 2021-11-05 08:02:51 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 08:02:51 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 714
ERROR - 2021-11-05 08:02:51 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 08:02:51 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 08:02:51 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 721
ERROR - 2021-11-05 08:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 08:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 08:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 08:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 08:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 08:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 08:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 08:05:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-05 08:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 08:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 08:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 08:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 08:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 08:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 08:06:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 08:07:35 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-05 08:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 08:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 08:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 08:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 08:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 08:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 08:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 08:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 08:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 08:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 08:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 08:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 08:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 08:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 10:09:55 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 10:09:55 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 10:09:55 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 716
ERROR - 2021-11-05 10:09:55 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 10:09:55 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 10:09:55 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 723
ERROR - 2021-11-05 10:10:54 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 10:10:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 10:10:54 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 716
ERROR - 2021-11-05 10:10:54 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 10:10:54 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 10:10:54 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 723
ERROR - 2021-11-05 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 10:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 10:12:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-05 10:12:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-05 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 10:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 10:14:08 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 10:14:08 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 10:14:08 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 716
ERROR - 2021-11-05 10:14:08 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 10:14:08 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 10:14:08 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 723
ERROR - 2021-11-05 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 11:56:24 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 11:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 11:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 11:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 11:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 11:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 11:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 11:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 12:02:38 --> Severity: Warning --> Illegal string offset 'flag' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 713
ERROR - 2021-11-05 12:02:38 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 715
ERROR - 2021-11-05 12:02:38 --> Severity: Warning --> Illegal string offset 'sys_pass' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 716
ERROR - 2021-11-05 12:02:38 --> Severity: Warning --> Illegal string offset 'organization_detail' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 12:02:38 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 717
ERROR - 2021-11-05 12:02:38 --> Severity: Warning --> Illegal string offset 'use_name' E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 723
ERROR - 2021-11-05 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-05 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-05 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-05 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-05 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-05 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-05 12:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-05 12:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\payment\viewform.php 73
ERROR - 2021-11-05 13:42:33 --> Severity: Error --> Class 'QRcode' not found E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 13:42:33 --> Severity: Error --> Class 'QRcode' not found E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 13:51:58 --> Severity: Error --> Class 'QRcode' not found E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 13:51:58 --> Severity: Error --> Class 'QRcode' not found E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrconst.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrconst.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrtools.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrtools.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrspec.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrspec.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrimage.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrimage.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrinput.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrinput.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrbitstream.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrbitstream.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrsplit.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrsplit.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrrscode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrrscode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrmask.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrmask.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(qrcode/qrencode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:52 --> Severity: Warning --> include(): Failed opening 'qrcode/qrencode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrconst.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrconst.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrtools.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrtools.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrspec.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrspec.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrimage.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrimage.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrinput.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrinput.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrbitstream.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrbitstream.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrsplit.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrsplit.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrrscode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrrscode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrmask.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrmask.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(qrcode/qrencode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:53 --> Severity: Warning --> include(): Failed opening 'qrcode/qrencode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrconst.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrconst.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrtools.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrtools.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrspec.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrspec.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrimage.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrimage.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrinput.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrinput.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrbitstream.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrbitstream.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrsplit.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrsplit.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrrscode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrrscode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrmask.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrmask.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrencode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrencode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrconst.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrconst.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrtools.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrtools.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrspec.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrspec.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrimage.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrimage.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrinput.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrinput.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrbitstream.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrbitstream.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrsplit.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrsplit.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrrscode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrrscode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrmask.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrmask.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrencode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrencode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrconst.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrconst.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 24
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrtools.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrtools.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 25
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrspec.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrspec.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 26
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrimage.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrimage.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 27
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrinput.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrinput.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 28
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrbitstream.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrbitstream.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 29
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrsplit.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrsplit.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 30
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrrscode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrrscode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 31
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrmask.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrmask.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 32
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(qrcode/qrencode.php): failed to open stream: No such file or directory E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 13:52:56 --> Severity: Warning --> include(): Failed opening 'qrcode/qrencode.php' for inclusion (include_path='E:\xamp\php\PEAR') E:\xamp\htdocs\crm\application\libraries\Ciqrcode.php 33
ERROR - 2021-11-05 14:19:05 --> Severity: Warning --> Missing argument 1 for Sales_order::QRcode() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 878
ERROR - 2021-11-05 14:19:05 --> Severity: Warning --> Missing argument 1 for Sales_order::QRcode() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 878
ERROR - 2021-11-05 14:55:02 --> Severity: Warning --> implode(): Invalid arguments passed E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 14:55:02 --> Severity: Warning --> implode(): Invalid arguments passed E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 14:55:36 --> Severity: Warning --> implode(): Invalid arguments passed E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 14:55:37 --> Severity: Warning --> implode(): Invalid arguments passed E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 14:56:58 --> Severity: Warning --> implode(): Invalid arguments passed E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 14:56:58 --> Severity: Warning --> implode(): Invalid arguments passed E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 15:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 15:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 15:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 15:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 880
ERROR - 2021-11-05 15:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
ERROR - 2021-11-05 15:06:07 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xamp\htdocs\crm\application\libraries\qrcode\qrsplit.php 250
ERROR - 2021-11-05 15:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 522
ERROR - 2021-11-05 15:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 522
ERROR - 2021-11-05 15:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 594
ERROR - 2021-11-05 15:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 688
ERROR - 2021-11-05 15:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
ERROR - 2021-11-05 15:06:08 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given E:\xamp\htdocs\crm\application\libraries\qrcode\qrsplit.php 250
ERROR - 2021-11-05 15:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 522
ERROR - 2021-11-05 15:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 522
ERROR - 2021-11-05 15:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 594
ERROR - 2021-11-05 15:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\libraries\qrcode\qrinput.php 688
ERROR - 2021-11-05 15:08:31 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
ERROR - 2021-11-05 15:08:31 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
ERROR - 2021-11-05 15:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
ERROR - 2021-11-05 15:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
ERROR - 2021-11-05 15:12:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
ERROR - 2021-11-05 15:12:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\controllers\Sales_order.php 881
