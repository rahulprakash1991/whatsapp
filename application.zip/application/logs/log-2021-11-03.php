<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-03 06:28:54 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 06:33:35 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 270
ERROR - 2021-11-03 06:33:53 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 270
ERROR - 2021-11-03 06:35:39 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\purchase_order\email_po.php 25
ERROR - 2021-11-03 06:37:42 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\purchase_order\email_po.php 25
ERROR - 2021-11-03 06:39:59 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\purchase_order\email_po.php 25
ERROR - 2021-11-03 06:40:57 --> Severity: Error --> Call to a member function result() on null E:\xamp\htdocs\crm\application\views\purchase_order\email_po.php 25
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: results E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 263
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: data E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 311
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: form_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 69
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 81
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 112
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: list_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 195
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-03 06:49:42 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: results E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 263
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: data E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 311
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: form_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 69
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 81
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 112
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: list_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 195
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-03 06:51:03 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-03 06:53:42 --> Severity: Notice --> Undefined property: CI_Loader::$pre E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 25
ERROR - 2021-11-03 06:53:42 --> Severity: Error --> Call to a member function getCurrencynew() on null E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 25
ERROR - 2021-11-03 06:54:27 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: form_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 69
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 81
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 112
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: list_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 195
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: results E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 301
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: form_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 69
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 81
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: acl E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 112
ERROR - 2021-11-03 06:54:27 --> Severity: Notice --> Undefined variable: list_tittle E:\xamp\htdocs\crm\application\views\masters\user_registration\viewform.php 195
ERROR - 2021-11-03 06:54:28 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-03 06:54:28 --> Severity: Notice --> Undefined variable: isGroup E:\xamp\htdocs\crm\application\libraries\Datatables.php 414
ERROR - 2021-11-03 07:00:55 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 07:01:42 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 07:03:16 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 07:11:08 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 08:01:11 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 08:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 08:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 08:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 08:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 08:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 08:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 08:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 08:17:54 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 08:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 08:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 08:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 08:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 08:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 08:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 08:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 08:22:34 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 08:37:53 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 08:39:05 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 08:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 08:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 08:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 08:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 08:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 08:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 08:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 08:59:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 08:59:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 08:59:35 --> Severity: Error --> Call to undefined function consoleLog() E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 261
ERROR - 2021-11-03 09:00:14 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 09:00:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 09:00:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 09:00:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 09:00:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 09:00:59 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 09:00:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 09:00:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-11-03 09:02:49 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 09:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:04:32 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 09:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:11:04 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 09:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:11:43 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\masters\user_registration\changepassword.php 34
ERROR - 2021-11-03 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:34:18 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 272
ERROR - 2021-11-03 09:34:36 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 272
ERROR - 2021-11-03 09:34:38 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 272
ERROR - 2021-11-03 09:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:34:43 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 272
ERROR - 2021-11-03 09:34:58 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\masters\User_registration.php 272
ERROR - 2021-11-03 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 53
ERROR - 2021-11-03 09:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 79
ERROR - 2021-11-03 09:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 105
ERROR - 2021-11-03 09:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 168
ERROR - 2021-11-03 09:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 201
ERROR - 2021-11-03 09:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 232
ERROR - 2021-11-03 09:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\dashboard.php 464
ERROR - 2021-11-03 09:54:52 --> Severity: Error --> Call to undefined function base_url1() E:\xamp\htdocs\crm\application\views\masters\user_registration\conformationemail.php 222
ERROR - 2021-11-03 10:08:40 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() E:\xamp\htdocs\crm\system\libraries\Email.php 1841
ERROR - 2021-11-03 10:47:31 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 71
ERROR - 2021-11-03 10:48:08 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 71
ERROR - 2021-11-03 10:48:09 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 71
ERROR - 2021-11-03 10:48:10 --> Severity: Error --> Call to undefined function lang() E:\xamp\htdocs\crm\application\views\Auth\login_form.php 71
ERROR - 2021-11-03 10:49:51 --> 404 Page Not Found: Recovery/index
ERROR - 2021-11-03 10:50:30 --> 404 Page Not Found: Auth/forgot_password
ERROR - 2021-11-03 10:50:31 --> 404 Page Not Found: Auth/forgot_password
ERROR - 2021-11-03 10:50:35 --> 404 Page Not Found: Auth/forgot_password
ERROR - 2021-11-03 10:53:46 --> Severity: Parsing Error --> syntax error, unexpected 'forgot_password' (T_STRING), expecting variable (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\Auth.php 652
ERROR - 2021-11-03 10:53:47 --> Severity: Parsing Error --> syntax error, unexpected 'forgot_password' (T_STRING), expecting variable (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\Auth.php 652
ERROR - 2021-11-03 10:54:38 --> Severity: Parsing Error --> syntax error, unexpected 'forgot_password' (T_STRING), expecting variable (T_VARIABLE) E:\xamp\htdocs\crm\application\controllers\Auth.php 652
ERROR - 2021-11-03 11:02:09 --> Severity: Parsing Error --> syntax error, unexpected '?' E:\xamp\htdocs\crm\application\views\templates\login_template.php 73
ERROR - 2021-11-03 11:47:51 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\crm\application\controllers\Auth.php 677
ERROR - 2021-11-03 12:26:54 --> Query error: Unknown column 'org_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_company_profile`
WHERE `org_id` = '1'
 LIMIT 1
ERROR - 2021-11-03 12:28:06 --> Query error: Unknown column 'org_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_company_profile`
WHERE `org_id` = '1'
 LIMIT 1
ERROR - 2021-11-03 12:28:08 --> Query error: Unknown column 'org_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_company_profile`
WHERE `org_id` = '1'
 LIMIT 1
ERROR - 2021-11-03 14:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\crm\application\views\payment\salesorderviewform.php 75
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 14:14:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
ERROR - 2021-11-03 15:01:31 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given E:\xamp\htdocs\crm\application\views\masters\user_role\viewform.php 98
